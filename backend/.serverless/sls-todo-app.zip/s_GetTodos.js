
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: '1jayso',
  applicationName: 'serverless-todo-app',
  appUid: 'HGxfkPQxGB60llBtx7',
  orgUid: '4fa82e0a-38c2-4c67-bd43-39d59346c2a3',
  deploymentUid: '8d6109d4-4bd5-4ea7-a1a5-9ff44f5ef748',
  serviceName: 'sls-todo-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'sls-todo-app-dev-GetTodos', timeout: 6 };

try {
  const userHandler = require('./src/lambda/http/getTodos.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}