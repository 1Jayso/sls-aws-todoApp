
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: '1jayso',
  applicationName: 'serverless-todo-app',
  appUid: 'HGxfkPQxGB60llBtx7',
  orgUid: '4fa82e0a-38c2-4c67-bd43-39d59346c2a3',
  deploymentUid: 'fd858f3d-5bee-4e74-972c-3a25aa5e7189',
  serviceName: 'sls-todo-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'sls-todo-app-dev-CreateTodo', timeout: 6 };

try {
  const userHandler = require('./src/lambda/http/createTodo.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}